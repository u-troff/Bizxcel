import type { Metadata } from "next";
import { StubPage } from "@/components/StubPage";

export const metadata: Metadata = { title: "Join our services" };

export default function Page() {
  return (
    <StubPage
      title="Join our services"
      intro="Follow the following steps and fill in a form to connect"
    />
  );
}
