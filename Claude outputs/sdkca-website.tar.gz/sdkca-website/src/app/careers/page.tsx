import type { Metadata } from "next";
import { StubPage } from "@/components/StubPage";
import { careers } from "@/content/sdk";

export const metadata: Metadata = { title: "Careers/Training" };

export default function Page() {
  return <StubPage title={careers.heading} intro={careers.tagline} />;
}
