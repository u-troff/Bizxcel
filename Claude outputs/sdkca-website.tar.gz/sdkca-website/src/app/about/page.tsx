import type { Metadata } from "next";
import { StubPage } from "@/components/StubPage";
import { about } from "@/content/sdk";

export const metadata: Metadata = { title: "Our Team" };

export default function Page() {
  return <StubPage title="Our Team" intro={about.intro} />;
}
