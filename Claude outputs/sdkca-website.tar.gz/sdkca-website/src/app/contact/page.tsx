import type { Metadata } from "next";
import { StubPage } from "@/components/StubPage";
import { contact } from "@/content/sdk";

export const metadata: Metadata = { title: "Contact Us" };

export default function Page() {
  return <StubPage title="Contact Us" intro={contact.contactBlurb} />;
}
