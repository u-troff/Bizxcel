import Link from "next/link";
import { ScrollHero } from "@/components/ScrollHero";
import {
  about,
  contact,
  entities,
  mission,
  services,
  testimonials,
  values,
  vision,
} from "@/content/sdk";

export default function HomePage() {
  return (
    <main>
      <ScrollHero />

      {/* Entities */}
      <section aria-labelledby="entities-heading" className="border-b border-line bg-paper">
        <div className="mx-auto max-w-6xl px-6 py-10">
          <h2 id="entities-heading" className="text-sm font-semibold uppercase tracking-[0.14em] !font-sans text-body">
            In association with
          </h2>
          <ul className="mt-5 grid gap-4 md:grid-cols-3">
            {entities.map((e) => (
              <li key={e.id} className="text-sm leading-relaxed">
                <span className="block font-semibold text-ink">{e.name}</span>
                <span>
                  {e.registrationLabel} {e.registration}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Services */}
      <section aria-labelledby="services-heading" className="mx-auto max-w-6xl px-6 py-20">
        <h2 id="services-heading" className="text-3xl font-semibold md:text-4xl">
          Services
        </h2>
        <ul className="mt-10 grid gap-px overflow-hidden rounded-sm border border-line bg-line sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s) => (
            <li key={s.slug} className="bg-white p-6 sm:last:col-span-2 lg:last:col-span-3">
              <h3 className="text-xl font-semibold">{s.title}</h3>
              <ul className="mt-3 space-y-1.5 text-sm leading-relaxed">
                {s.items.slice(0, 3).map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
              <Link
                href={`/services#${s.slug}`}
                className="mt-4 inline-block text-sm font-semibold text-ink underline decoration-brass underline-offset-4"
              >
                Read more<span className="sr-only"> about {s.title}</span>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      {/* About */}
      <section aria-labelledby="about-heading" className="bg-paper">
        <div className="mx-auto grid max-w-6xl gap-10 px-6 py-20 md:grid-cols-5">
          <h2 id="about-heading" className="text-3xl font-semibold md:col-span-2 md:text-4xl">
            {about.heading}
          </h2>
          <div className="md:col-span-3">
            <p className="text-lg leading-relaxed">{about.body}</p>
            <Link
              href="/about"
              className="mt-6 inline-block text-sm font-semibold text-ink underline decoration-brass underline-offset-4"
            >
              Meet the team
            </Link>
          </div>
        </div>
      </section>

      {/* Vision / Mission / Values */}
      <section aria-label="Vision, mission and values" className="mx-auto max-w-6xl px-6 py-20">
        <div className="grid gap-10 md:grid-cols-3">
          <div>
            <h2 className="text-2xl font-semibold">Vision</h2>
            <p className="mt-3 leading-relaxed">{vision}</p>
          </div>
          <div>
            <h2 className="text-2xl font-semibold">Mission</h2>
            <p className="mt-3 leading-relaxed">{mission}</p>
          </div>
          <div>
            <h2 className="text-2xl font-semibold">Values</h2>
            <ul className="mt-3 space-y-1.5">
              {values.map((v) => (
                <li key={v} className="flex items-center gap-3">
                  <span aria-hidden="true" className="h-1.5 w-1.5 rounded-full bg-brass" />
                  {v}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Testimonials — PLACEHOLDERS ONLY. The live site shows lorem ipsum; we never invent quotes. */}
      <section aria-labelledby="testimonials-heading" className="border-y border-line bg-paper">
        <div className="mx-auto max-w-6xl px-6 py-20">
          <h2 id="testimonials-heading" className="text-3xl font-semibold md:text-4xl">
            What clients say
          </h2>
          <ul className="mt-10 grid gap-6 md:grid-cols-3">
            {testimonials.map((t) => (
              <li
                key={t.id}
                className="rounded-sm border border-dashed border-body/40 bg-white p-6 text-sm leading-relaxed"
              >
                <p className="text-xs font-semibold uppercase tracking-[0.14em] text-brass">Placeholder</p>
                <p className="mt-3">Client testimonial to be supplied. No quote has been written for this slot.</p>
                <p className="mt-4 text-body/70">Name, role and company — awaiting client approval.</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Contact */}
      <section aria-labelledby="contact-heading" className="mx-auto max-w-6xl px-6 py-20">
        <div className="grid gap-10 md:grid-cols-2">
          <div>
            <h2 id="contact-heading" className="text-3xl font-semibold md:text-4xl">
              Contact us
            </h2>
            <p className="mt-4 text-lg leading-relaxed">{contact.contactBlurbShort}</p>
            <div className="mt-6 flex flex-wrap gap-4">
              <a
                href={contact.emailHref}
                className="rounded-sm bg-navy px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-navy-soft"
              >
                Email {contact.email}
              </a>
              <Link
                href="/contact"
                className="rounded-sm border border-navy/30 px-6 py-3 text-sm font-semibold text-ink transition-colors hover:bg-paper"
              >
                All contact options
              </Link>
            </div>
          </div>
          <dl className="grid gap-5 text-sm sm:grid-cols-2">
            <div>
              <dt className="font-semibold text-ink">SDK Reception</dt>
              <dd className="mt-1">
                <a href={contact.receptionPhoneHref} className="underline decoration-brass underline-offset-4">
                  {contact.receptionPhone}
                </a>
              </dd>
            </div>
            <div>
              <dt className="font-semibold text-ink">Address</dt>
              <dd className="mt-1">
                {contact.address.lines.map((l) => (
                  <span key={l} className="block">
                    {l}
                  </span>
                ))}
              </dd>
            </div>
            <div className="sm:col-span-2">
              <dt className="font-semibold text-ink">Hours</dt>
              <dd className="mt-1 space-y-0.5">
                {contact.hours.map((h) => (
                  <span key={h.days} className="block">
                    {h.days}: {h.time}
                  </span>
                ))}
              </dd>
            </div>
          </dl>
        </div>
      </section>
    </main>
  );
}
