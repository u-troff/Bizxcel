import type { Metadata } from "next";
import { StubPage } from "@/components/StubPage";
import { news } from "@/content/sdk";

export const metadata: Metadata = { title: "News" };

export default function Page() {
  return <StubPage title={news.heading} intro={news.tagline} />;
}
