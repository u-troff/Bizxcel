import type { Metadata } from "next";
import { StubPage } from "@/components/StubPage";
import { legal } from "@/content/sdk";

export const metadata: Metadata = { title: "Website Privacy Statement" };

export default function Page() {
  return (
    <StubPage
      title={legal.privacy.label}
      intro={`Last updated ${legal.privacy.lastUpdated}. Full statement text to be copied across from the live site before launch.`}
    />
  );
}
