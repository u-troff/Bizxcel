import type { Metadata } from "next";
import { StubPage } from "@/components/StubPage";
import { servicesIntro } from "@/content/sdk";

export const metadata: Metadata = { title: "Services" };

export default function Page() {
  return <StubPage title="Services" intro={servicesIntro} />;
}
