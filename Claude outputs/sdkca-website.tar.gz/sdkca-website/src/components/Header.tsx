import Link from "next/link";
import { nav, site } from "@/content/sdk";

export function Header() {
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-white/10 bg-navy/95 text-white backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-6">
        <Link href="/" className="font-serif text-xl font-semibold tracking-wide text-white">
          {site.name}
        </Link>

        <nav aria-label="Primary" className="hidden items-center gap-6 text-sm lg:flex">
          {nav.slice(1).map((item) => (
            <Link key={item.href} href={item.href} className="text-white/80 transition-colors hover:text-white">
              {item.label}
            </Link>
          ))}
        </nav>

        {/* No-JS mobile menu: <details> needs no client component. */}
        <details className="relative lg:hidden">
          <summary className="cursor-pointer list-none rounded-sm border border-white/30 px-3 py-1.5 text-sm">
            Menu
          </summary>
          <nav
            aria-label="Mobile"
            className="absolute right-0 mt-3 flex w-56 flex-col gap-1 rounded-sm border border-white/10 bg-navy p-3 shadow-lg"
          >
            {nav.map((item) => (
              <Link key={item.href} href={item.href} className="rounded-sm px-3 py-2 text-white/85 hover:bg-white/10">
                {item.label}
              </Link>
            ))}
          </nav>
        </details>
      </div>
    </header>
  );
}
