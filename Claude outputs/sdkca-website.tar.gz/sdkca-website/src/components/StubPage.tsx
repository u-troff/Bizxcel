import Link from "next/link";

/**
 * Placeholder page for the demo build. Real copy for every page already lives in src/content/sdk.ts,
 * so "building out" a stub is a matter of rendering that data — no new copy needs writing.
 */
export function StubPage({
  title,
  intro,
  children,
}: {
  title: string;
  intro?: string;
  children?: React.ReactNode;
}) {
  return (
    <main className="mx-auto max-w-3xl px-6 pb-24 pt-36">
      <h1 className="text-4xl font-semibold md:text-5xl">{title}</h1>
      {intro && <p className="mt-5 text-lg leading-relaxed">{intro}</p>}
      {children}
      <p className="mt-12 rounded-sm border border-line bg-paper px-4 py-3 text-sm">
        This page is a stub in the demo build. <Link href="/" className="font-semibold text-ink underline">Back to home</Link>
      </p>
    </main>
  );
}
