"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { hero, site } from "@/content/sdk";

gsap.registerPlugin(ScrollTrigger);

/**
 * Scroll-scrubbed hero: a pre-rendered frame sequence drawn to a canvas, driven by one ScrollTrigger.
 *
 * Frames are produced by `npm run frames` (see scripts/prepare-frames.mjs), which also writes
 * public/scroll-hero/manifest.json. If the manifest (or the frames) are missing, or the visitor prefers
 * reduced motion, this renders the plain static hero instead — so the page is never broken or empty.
 *
 * Restraint is deliberate: SDK|CA is a conservative firm. Motion lives on the hero only.
 */

const BASE = "/scroll-hero";
const MOBILE_QUERY = "(max-width: 767px)";
const REDUCED_MOTION_QUERY = "(prefers-reduced-motion: reduce)";

// Pin length in px. Phones get a much shorter pin so touch scrolling never feels hijacked.
const SCROLL_DESKTOP = 1600;
const SCROLL_MOBILE = 800;

// Start scrubbing once this many frames are decoded; the rest stream in behind.
const MIN_FRAMES_TO_START = 24;

type Manifest = { count: number; mobileCount: number; poster?: boolean };
type FrameSet = { dir: string; count: number; scroll: number };

const framePath = (dir: string, index: number) =>
  `${dir}/frame-${String(index + 1).padStart(3, "0")}.webp`;

// Where each text cue fades in/out, as a fraction of scroll progress. Tune these to the footage.
// Each cue starts fading in exactly as the previous one fades out, so the hero never shows bare footage.
const FADE = 0.06;
const CUES = [
  { id: "intro", from: null, to: 0.3 }, // visible before any scrolling
  { id: "trust", from: 0.3, to: 0.65 },
  { id: "cta", from: 0.65, to: null }, // holds to the end
] as const;

export function ScrollHero() {
  const rootRef = useRef<HTMLDivElement>(null);
  const pinRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Frame state lives in refs so scroll-rate updates never trigger a React render.
  const configRef = useRef<FrameSet | null>(null);
  const imagesRef = useRef<HTMLImageElement[]>([]);
  const loadedRef = useRef<boolean[]>([]);
  const frameIndexRef = useRef(0);

  const [scrubbing, setScrubbing] = useState(false);
  const [loadProgress, setLoadProgress] = useState(0);
  const [hasPoster, setHasPoster] = useState(false);

  // Pass 1 — decide whether to scrub at all, then preload the right frame set.
  useEffect(() => {
    if (window.matchMedia(REDUCED_MOTION_QUERY).matches) return;

    let cancelled = false;

    (async () => {
      let manifest: Manifest;
      try {
        const res = await fetch(`${BASE}/manifest.json`, { cache: "no-store" });
        if (!res.ok || !(res.headers.get("content-type") ?? "").includes("json")) return;
        manifest = (await res.json()) as Manifest;
      } catch {
        return; // no frames yet — static hero stays
      }
      if (cancelled || !manifest.count) return;
      setHasPoster(Boolean(manifest.poster));

      const mobile = window.matchMedia(MOBILE_QUERY).matches && manifest.mobileCount > 0;
      const config: FrameSet = mobile
        ? { dir: `${BASE}/frames-mobile`, count: manifest.mobileCount, scroll: SCROLL_MOBILE }
        : { dir: `${BASE}/frames`, count: manifest.count, scroll: SCROLL_DESKTOP };
      configRef.current = config;
      loadedRef.current = new Array(config.count).fill(false);
      imagesRef.current = [];

      let settled = 0;
      const need = Math.min(MIN_FRAMES_TO_START, config.count);

      const settle = (index: number, ok: boolean) => {
        if (cancelled) return;
        if (ok) loadedRef.current[index] = true;
        settled += 1;
        setLoadProgress(settled / config.count);
        if (loadedRef.current[0] && settled >= need) setScrubbing(true);
      };

      for (let i = 0; i < config.count; i += 1) {
        const img = new window.Image();
        img.decoding = "async";
        img.fetchPriority = "low"; // don't compete with CSS / LCP on first load
        img.src = framePath(config.dir, i);
        img.onload = () => settle(i, true);
        img.onerror = () => settle(i, false); // a dropped frame must not stall the loader
        imagesRef.current.push(img);
      }
    })();

    return () => {
      cancelled = true;
      imagesRef.current.forEach((img) => {
        img.onload = null;
        img.onerror = null;
      });
    };
  }, []);

  // Pass 2 — the canvas is mounted, so wire up drawing and the scroll timeline.
  useEffect(() => {
    const config = configRef.current;
    if (!scrubbing || !config) return;

    let rafId = 0;

    // Scrubbing can outrun the network: fall back to the nearest decoded frame instead of clearing.
    const nearestLoaded = (index: number) => {
      const loaded = loadedRef.current;
      if (loaded[index]) return index;
      for (let o = 1; o < config.count; o += 1) {
        if (loaded[index - o]) return index - o;
        if (loaded[index + o]) return index + o;
      }
      return -1;
    };

    const draw = () => {
      rafId = 0;
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext("2d");
      if (!canvas || !ctx) return;
      const src = nearestLoaded(frameIndexRef.current);
      if (src === -1) return;
      const img = imagesRef.current[src];
      const { width, height } = canvas;
      // Cover-fit: fill the viewport, crop whichever axis overflows.
      const scale = Math.max(width / img.naturalWidth, height / img.naturalHeight);
      const w = img.naturalWidth * scale;
      const h = img.naturalHeight * scale;
      ctx.drawImage(img, (width - w) / 2, (height - h) / 2, w, h);
    };

    const scheduleDraw = () => {
      if (!rafId) rafId = requestAnimationFrame(draw); // never draw inside the scroll callback
    };

    const resize = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(canvas.clientWidth * dpr);
      canvas.height = Math.round(canvas.clientHeight * dpr);
      draw();
    };
    resize();

    // Late-arriving frames replace whatever stand-in is currently painted.
    imagesRef.current.forEach((img, index) => {
      const prev = img.onload;
      img.onload = (e) => {
        (prev as ((ev: Event) => void) | null)?.call(img, e as Event);
        if (index === frameIndexRef.current) scheduleDraw();
      };
    });

    const ctx = gsap.context(() => {
      // One ScrollTrigger drives canvas AND text, so footage and copy can never drift apart.
      const tl = gsap.timeline({
        defaults: { ease: "none" },
        scrollTrigger: {
          trigger: rootRef.current,
          start: "top top",
          end: `+=${config.scroll}`,
          pin: pinRef.current,
          scrub: 0.4,
          invalidateOnRefresh: true,
          onUpdate: (self) => {
            const next = Math.min(config.count - 1, Math.round(self.progress * (config.count - 1)));
            if (next !== frameIndexRef.current) {
              frameIndexRef.current = next;
              scheduleDraw();
            }
          },
        },
      });

      const block = (id: string) => rootRef.current?.querySelector<HTMLElement>(`[data-block="${id}"]`) ?? null;

      for (const cue of CUES) {
        if (cue.from !== null) {
          tl.fromTo(block(cue.id), { autoAlpha: 0, y: 20 }, { autoAlpha: 1, y: 0, duration: FADE }, cue.from);
        }
        if (cue.to !== null) {
          tl.to(block(cue.id), { autoAlpha: 0, y: -20, duration: FADE }, cue.to);
        }
      }
      tl.set({}, {}, 1); // pad to exactly 1 so the positions above read as scroll progress
    }, rootRef);

    window.addEventListener("resize", resize);
    ScrollTrigger.refresh();

    return () => {
      window.removeEventListener("resize", resize);
      if (rafId) cancelAnimationFrame(rafId);
      ctx.revert();
    };
  }, [scrubbing]);

  const intro = hero.cues[0].text;

  return (
    <div ref={rootRef} className="relative">
      <div
        ref={pinRef}
        className={`relative w-full overflow-hidden bg-navy text-white ${scrubbing ? "h-svh" : ""}`}
      >
        {scrubbing && (
          <>
            <canvas ref={canvasRef} aria-hidden="true" className="absolute inset-0 h-full w-full" />
            {/* Scrim keeps white copy legible over any frame. */}
            <div
              aria-hidden="true"
              className="absolute inset-0 bg-gradient-to-r from-navy/90 via-navy/65 to-navy/30"
            />
          </>
        )}

        {/* Static poster (last frame) until/unless the scrub takes over. */}
        {!scrubbing && hasPoster && (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={`${BASE}/poster.webp`}
            alt=""
            aria-hidden="true"
            className="absolute inset-0 h-full w-full object-cover opacity-40"
          />
        )}

        {/*
          The static hero is always in the HTML: crawlers, no-JS visitors, reduced-motion users and screen
          readers get the real h1 and copy. Once scrubbing starts it is hidden visually only.
        */}
        <div className={scrubbing ? "sr-only" : "relative mx-auto max-w-6xl px-6 py-36 md:py-44"}>
          <p className="text-sm font-semibold uppercase tracking-[0.18em] text-brass">{hero.eyebrow}</p>
          <h1 className="mt-5 max-w-3xl font-serif text-4xl font-semibold leading-tight !text-white md:text-6xl">
            {hero.headline}
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-white/80">{site.description}</p>
          {!scrubbing && <HeroActions />}
        </div>

        {scrubbing && (
          <div aria-hidden="true" className="pointer-events-none absolute inset-0">
            <Block id="intro" visibleAtStart>
              <p className="text-sm font-semibold uppercase tracking-[0.18em] text-brass">{hero.eyebrow}</p>
              <p className="mt-5 max-w-3xl font-serif text-4xl font-semibold leading-tight md:text-6xl">{intro}</p>
            </Block>
            <Block id="trust">
              <p className="max-w-2xl font-serif text-3xl font-semibold leading-snug md:text-5xl">
                {hero.cues[1].text}
              </p>
            </Block>
          </div>
        )}

        {/* The CTA block holds real links, so it sits outside the aria-hidden layer.
            autoAlpha keeps it visibility:hidden — and therefore untabbable — until it is revealed. */}
        {scrubbing && (
          <div
            data-block="cta"
            className="absolute inset-0 flex flex-col justify-center"
            style={{ opacity: 0, visibility: "hidden" }}
          >
            <div className="mx-auto w-full max-w-6xl px-6">
              <p className="max-w-2xl font-serif text-2xl font-semibold leading-snug md:text-4xl">
                {hero.cues[2].text}
              </p>
              <HeroActions />
            </div>
          </div>
        )}

        {loadProgress > 0 && !scrubbing && (
          <div className="absolute inset-x-0 bottom-8 flex justify-center" aria-hidden="true">
            <div className="h-px w-40 overflow-hidden bg-white/20">
              <div
                className="h-full bg-brass transition-[width] duration-200"
                style={{ width: `${Math.round(loadProgress * 100)}%` }}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function Block({
  id,
  visibleAtStart = false,
  children,
}: {
  id: string;
  visibleAtStart?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div
      data-block={id}
      className="absolute inset-0 flex flex-col justify-center"
      style={visibleAtStart ? undefined : { opacity: 0, visibility: "hidden" }}
    >
      <div className="mx-auto w-full max-w-6xl px-6">{children}</div>
    </div>
  );
}

function HeroActions() {
  return (
    <div className="pointer-events-auto mt-9 flex flex-wrap gap-4">
      <Link
        href={hero.cta.href}
        className="rounded-sm bg-brass px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-[#8a6c33]"
      >
        {hero.cta.label}
      </Link>
      <Link
        href={hero.secondaryCta.href}
        className="rounded-sm border border-white/40 px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-white/10"
      >
        {hero.secondaryCta.label}
      </Link>
    </div>
  );
}
