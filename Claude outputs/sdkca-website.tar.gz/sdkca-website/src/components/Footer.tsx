import Link from "next/link";
import { contact, entities, legal, nav, site, social } from "@/content/sdk";

export function Footer() {
  return (
    <footer className="bg-navy text-white/80">
      <div className="mx-auto grid max-w-6xl gap-10 px-6 py-14 md:grid-cols-4">
        <div className="md:col-span-1">
          <p className="font-serif text-xl font-semibold text-white">{site.name}</p>
          <p className="mt-3 text-sm leading-relaxed">{site.descriptor}</p>
        </div>

        <nav aria-label="Footer" className="text-sm">
          <p className="mb-3 font-semibold text-white">Site</p>
          <ul className="space-y-2">
            {nav.map((item) => (
              <li key={item.href}>
                <Link href={item.href} className="hover:text-white">
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className="text-sm">
          <p className="mb-3 font-semibold text-white">Contact</p>
          <ul className="space-y-2">
            <li>
              <a href={contact.receptionPhoneHref} className="hover:text-white">
                {contact.receptionPhone}
              </a>
            </li>
            <li>
              <a href={contact.emailHref} className="hover:text-white">
                {contact.email}
              </a>
            </li>
            <li>
              {contact.address.lines.map((l) => (
                <span key={l} className="block">
                  {l}
                </span>
              ))}
            </li>
          </ul>
          <ul className="mt-4 flex gap-4">
            {social.map((s) => (
              <li key={s.label}>
                <a href={s.href} target="_blank" rel="noopener noreferrer" className="hover:text-white">
                  {s.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div className="text-sm">
          <p className="mb-3 font-semibold text-white">Legal</p>
          <ul className="space-y-2">
            <li>
              <Link href="/privacy" className="hover:text-white">
                {legal.privacy.label}
              </Link>
            </li>
            <li>
              <a href={legal.paiaManual.href} target="_blank" rel="noopener noreferrer" className="hover:text-white">
                {legal.paiaManual.label}
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="mx-auto max-w-6xl px-6 py-6 text-xs leading-relaxed text-white/60">
          {entities.map((e) => (
            <p key={e.id}>
              {e.name} | {e.registrationLabel} {e.registration}
            </p>
          ))}
        </div>
      </div>
    </footer>
  );
}
