# SDK|CA — website rebuild (class demo)

Next.js (App Router) + Tailwind v4 + GSAP ScrollTrigger. Demo for the PLB Automation class, 16 Oct 2026.
Homepage fully built; every other route is a stub that already pulls its intro from the content file.

## Run it

```bash
npm install
npm run dev          # http://localhost:3000
npm run build        # production build (what Vercel runs)
```

## Where things live

| Path | What |
|---|---|
| `src/content/sdk.ts` | **All site copy in one file** — services, entities, contacts, about/vision/mission/values, leadership, join steps, careers, news, legal links, hero cues. Every block is tagged with its source page; `CHECK:` comments mark things to confirm with the client. |
| `src/components/ScrollHero.tsx` | The scroll-scrubbed hero (canvas + GSAP). Falls back to a static hero if there are no frames, on reduced motion, or if anything fails. |
| `scripts/prepare-frames.mjs` | ezgif frames in → optimised WebP sets + `manifest.json` out. |
| `public/scroll-hero/` | Output of the script (empty until you run it). |
| `src/app/**/page.tsx` | `/` built; `/about /services /join /careers /news /contact /privacy` are stubs. |

## The 5-step scroll method, mapped to this repo

1. Generate key images (Gemini).
2. Turn them into a short 3D-style video (Google Flow).
3. Video → frames at ezgif.com (export PNG/JPG).
4. **`npm run frames -- ~/path/to/ezgif-frames`** → writes `public/scroll-hero/{frames,frames-mobile,poster.webp,manifest.json}`. Refresh: the hero starts scrubbing, no code change.
5. Layer text: edit `hero.cues` in `src/content/sdk.ts` and the `CUES` timing table at the top of `ScrollHero.tsx`.

Tips from the BizXcel / VineVibe builds: ship ~60 frames, not 168 (BizXcel: 60 frames ≈ 2.3 MB; the raw ezgif PNGs were 209 MB). `--limit 60` trims the sequence; `--width 1600` is the default.

## Behaviour baked in

- Motion on the hero only; everything below is plain and static.
- `prefers-reduced-motion: reduce` → no pin, no canvas, static hero with the same copy.
- Phones → half the frames at 900px wide and a shorter pin (800px vs 1600px), so touch scrolling never feels hijacked.
- No frames / no manifest → static hero (the page is never blank).
- The real `<h1>` and copy are always in the HTML (SEO, no-JS, screen readers).
- Preview deployments are `noindex` (see `src/app/layout.tsx`). **Remove before launch.**
- System font stack, no web fonts, no images below the hero → fast.

## Not done on purpose

- Contact form (homepage links to `mailto:`; `/contact` is a stub). Wire a real form before launch.
- Testimonials are visible placeholders. The live site shows lorem ipsum; nothing is invented.
- Team photos, logos and brand colours — palette in `globals.css` is a placeholder.
- Privacy statement text — only a summary is in the content file. Copy the verbatim text from the live site.

## Open items for the client (also flagged as `CHECK:` in the content file)

- Source typos: Vision says "outmost best" (probably "utmost"); values list ends "Loyal"; careers copy has "polies", "continues training", "were a variety".
- Two PAIA manuals are linked on the live site (2022 vs 2021). Which is current?
- Service → entity mapping is inferred from logo order on `service.html`.
- Live "Sole Proprietor" sign-up link has a typo (`hhttps://`) and is broken — fixed in the content file.
- News links all go to `dotnews.co.za`; the legacy "Financial Services Board" and "Department of Labour" links were left out.
