#!/usr/bin/env node
/**
 * Turn an ezgif frame export into the optimised frame sets the ScrollHero component expects.
 *
 *   npm run frames -- <folder-of-ezgif-frames> [--limit 60] [--width 1600]
 *
 * Writes (all under public/scroll-hero/):
 *   frames/frame-001.webp …          desktop set, every frame, <width>px wide
 *   frames-mobile/frame-001.webp …   phone set, every 2nd frame, 900px wide
 *   poster.webp                      last frame — used for reduced-motion / before frames load
 *   manifest.json                    { count, mobileCount, poster } — the component reads this
 *
 * Why it exists: ezgif PNGs are ~1MB each (168 of them ≈ 200MB). Scroll-scrubbing does not need that.
 * BizXcel ships 60 frames at ~2.3MB total; VineVibe ships ~65. Aim for the same here.
 */
import sharp from "sharp";
import { readdir, mkdir, rm, stat, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const args = process.argv.slice(2);
const flag = (name, fallback) => {
  const i = args.indexOf(`--${name}`);
  return i === -1 ? fallback : Number(args[i + 1]);
};
const src = args.find((a, i) => !a.startsWith("--") && !(args[i - 1] ?? "").startsWith("--"));

if (!src) {
  console.error("Usage: npm run frames -- <folder-of-ezgif-frames> [--limit N] [--width 1600]");
  process.exit(1);
}

const LIMIT = flag("limit", Infinity); // cut the sequence early if the end of the footage isn't wanted
const WIDTH = flag("width", 1600);

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const out = path.join(root, "public", "scroll-hero");
const outDesktop = path.join(out, "frames");
const outMobile = path.join(out, "frames-mobile");

// ezgif padding is not guaranteed — sort by the numeric run in the filename, not alphabetically.
const naturalKey = (name) => {
  const m = name.match(/(\d+)(?=\.\w+$)/);
  return m ? Number(m[1]) : Number.MAX_SAFE_INTEGER;
};

const all = (await readdir(src))
  .filter((f) => /\.(png|jpe?g|webp)$/i.test(f))
  .sort((a, b) => naturalKey(a) - naturalKey(b) || a.localeCompare(b));

if (all.length === 0) {
  console.error(`No images found in ${src}`);
  process.exit(1);
}

const files = all.slice(0, LIMIT);
console.log(`Found ${all.length} frames in ${src}; using ${files.length} (first: ${files[0]}, last: ${files.at(-1)})`);

for (const dir of [outDesktop, outMobile]) {
  await rm(dir, { recursive: true, force: true });
  await mkdir(dir, { recursive: true });
}

const pad = (n) => String(n).padStart(3, "0");

await Promise.all(
  files.map((file, i) =>
    sharp(path.join(src, file))
      .resize({ width: WIDTH, withoutEnlargement: true })
      .webp({ quality: 72, effort: 6 })
      .toFile(path.join(outDesktop, `frame-${pad(i + 1)}.webp`)),
  ),
);

// Phones: every 2nd frame, smaller — always keep the final frame.
const mobileIdx = files.map((_, i) => i).filter((i) => i % 2 === 0);
if (mobileIdx.at(-1) !== files.length - 1) mobileIdx.push(files.length - 1);

await Promise.all(
  mobileIdx.map((srcIndex, i) =>
    sharp(path.join(src, files[srcIndex]))
      .resize({ width: 900, withoutEnlargement: true })
      .webp({ quality: 68, effort: 6 })
      .toFile(path.join(outMobile, `frame-${pad(i + 1)}.webp`)),
  ),
);

await sharp(path.join(src, files.at(-1)))
  .resize({ width: WIDTH, withoutEnlargement: true })
  .webp({ quality: 80, effort: 6 })
  .toFile(path.join(out, "poster.webp"));

await writeFile(
  path.join(out, "manifest.json"),
  JSON.stringify({ count: files.length, mobileCount: mobileIdx.length, poster: true }, null, 2) + "\n",
);

const dirSize = async (dir) => {
  let total = 0;
  for (const f of await readdir(dir)) total += (await stat(path.join(dir, f))).size;
  return total;
};
const mb = (n) => (n / 1024 / 1024).toFixed(2) + " MB";
const d = await dirSize(outDesktop);
console.log(`\nDesktop: ${files.length} frames, ${mb(d)} (avg ${(d / files.length / 1024).toFixed(0)} KB)`);
console.log(`Mobile:  ${mobileIdx.length} frames, ${mb(await dirSize(outMobile))}`);
if (d / files.length > 150 * 1024) console.warn("⚠ Average frame > 150KB — lower --width or trim with --limit.");
console.log("Wrote manifest.json — refresh the page and the scroll hero picks it up.");
