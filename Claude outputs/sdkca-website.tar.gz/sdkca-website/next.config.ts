import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Frames are already WebP and served as static files from /public, so next/image is not involved.
  async headers() {
    return [
      {
        // Frames never change once exported; let the browser and Vercel's CDN keep them.
        source: "/scroll-hero/:path*",
        headers: [{ key: "Cache-Control", value: "public, max-age=31536000, immutable" }],
      },
    ];
  },
};

export default nextConfig;
